
let MYSQL_CONFIG = {};

MYSQL_CONFIG = {
    host: 'rm-rj948ttaj8p89kl1wmo.mysql.rds.aliyuncs.com',
    user: 'testuser',
    password: 'Qq584167495',
    port: 3306,
    database: 'RUGBY'
}

module.exports = {
    MYSQL_CONFIG
}
